<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Paymentgateway extends Model
{
    protected $table = 'payment_gateway';
    protected $primaryKey = 'id';

     
}
?>
<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class TimeTable extends Model
{
    protected $table = 'time_table';
    protected $primaryKey = 'id';
}
?>
<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class NewsLetter extends Model
{
    protected $table = 'subscriber';
    protected $primaryKey = 'id';

     
}
?>
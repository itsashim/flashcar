<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class DepartService extends Model
{
    protected $table = 'department_service';
    protected $primaryKey = 'id';

     
}
?>
<?php

namespace App\Http\Controllers\API;

use App\City;
use App\User;
use App\Order;
use App\Patient;
use App\Product;
use App\Category;
use App\Hospital;
use Carbon\Carbon;
use App\Model\Doctor;
use App\Prescription;
use App\Model\TimeTable;
use App\Model\Department;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Setting;

class CommonController extends Controller
{
    public function cities(Request $request)
    {
        $cities = City::orderBy('name','ASC')->paginate(20);
        return response(['status'=>true,'data'=>$cities]);
    }

    public function settings()
    {
        $setting = Setting::first();
        return response($setting);
    }
    
    public function hospitals(Request $request)
    {
        $hospitals = Hospital::with('departments','city')->withCount('departments')->orderBy('name','ASC');
        if($request->city_id)
            $hospitals = $hospitals->where('city_id',$request->city_id);
        $hospitals = $hospitals->paginate(20);
        foreach($hospitals as $hospital){
            foreach($hospital->departments as $department){
                $department->doctors_count = Doctor::where('department_id',$department->id)->count();
            }
        }
        return response(['status'=>true,'data'=>$hospitals]);
    }
    
    public function departments(Request $request)
    {
        $departments = Department::orderBy('name','ASC')->paginate(20);
        foreach($departments as $department){
            $department->doctors_count = Doctor::where('department_id',$department->id)->count();
        }
        return response(['status'=>true,'data'=>$departments]);
    }
    
    public function doctors(Request $request)
    {
        $doctors = Doctor::orderBy('name','ASC');
        
        if($request->hospital_id)
            $doctors = $doctors->where('hospital_id',$request->hospital_id);
        if($request->department_id)
            $doctors = $doctors->where('department_id',$request->department_id);

        if($request->search){
            $search = $request->search;
            $doctors = $doctors->where('name','LIKE',"%{$search}%");
        }

        $doctors = $doctors->paginate(20);
        $dayOfWeek = Carbon::now()->dayOfWeek+1;
        
        foreach($doctors as $doctor){
            $todayTimeTable = TimeTable::where('doctor_id',$doctor->id)->where('day',$dayOfWeek)->first();
            if($todayTimeTable){

                if($dayOfWeek==6){

                    $tommorowTimeTable = TimeTable::where('doctor_id',$doctor->id)->where('day',$dayOfWeek+1)->first();
                    $dayAfterTommorowTimeTable = TimeTable::where('doctor_id',$doctor->id)->where('day',1)->first();
                    
               }elseif($dayOfWeek==7){
                    $dayAfterTommorowTimeTable = TimeTable::where('doctor_id',$doctor->id)->where('day',2)->first();
                    $tommorowTimeTable = TimeTable::where('doctor_id',$doctor->id)->where('day',1)->first();
                    
               }else{
    
                    $tommorowTimeTable = TimeTable::where('doctor_id',$doctor->id)->where('day',$dayOfWeek+1)->first();
    
                    $dayAfterTommorowTimeTable = TimeTable::where('doctor_id',$doctor->id)->where('day',$dayOfWeek+2)->first();
                }
    
                $hospital = Hospital::where('id',$doctor->hospital_id)->first();
                if($hospital)
                    $fee = $hospital->appointment_fee;
                else
                    $fee = $doctor->appointment_fee;
    
                $doctor->appointment_fee = $fee;
    
                $todayTimes = [];
                $todayToken = $todayTimeTable->token;
                $tokenTime = 0;
                for($i=0;$i<$todayToken; $i++){
                    if($i==0){
                        $appointmentTime = $todayTimeTable->from;
                    }else{
                        $appointmentTime = Carbon::parse($todayTimeTable->from)->addMinutes($tokenTime+20)->format('H:i');
                        $tokenTime=$tokenTime+20;
                    }
                    array_push($todayTimes,$appointmentTime);
                }
    
                $todayFinalTimes = [
                    'date'=>Carbon::now()->format('Y-m-d'),
                    'from'=>$todayTimeTable->from,
                    'to'=>$todayTimeTable->to,
                    'availableTimes'=> $todayTimes,
                ];
    
                $tommorrowToken = $tommorowTimeTable->token;
                $tokenTime = 0;
                $tommorrowTimes = [];
    
                for($i=0;$i<$tommorrowToken; $i++):
                    if($i==0):
                        $appointmentTime = $tommorowTimeTable->from;
                    else:
                        $appointmentTime = Carbon::parse($tommorowTimeTable->from)->addMinutes($tokenTime+20)->format('H:i');
                        $tokenTime=$tokenTime+20;
                    endif;
                    array_push($tommorrowTimes,$appointmentTime);
                endfor;
    
                $tommorowFinalTimes = [
                    'date'=> Carbon::now()->addDays(1)->format('Y-m-d'),
                    'from'=> $tommorowTimeTable->from,
                    'to' => $tommorowTimeTable->to,
                    'availableTimes'=>$tommorrowTimes,
                ];
    
                $dayAfterTommorrowToken = $dayAfterTommorowTimeTable->token;
                $tokenTime = 0;
                $thirdTimes = [];
                for($i=0;$i<$dayAfterTommorrowToken; $i++):
                    if($i==0):
                        $appointmentTime = $dayAfterTommorowTimeTable->from;
                    else:
                        $appointmentTime = Carbon::parse($tommorowTimeTable->from)->addMinutes($tokenTime+20)->format('H:i'); 
                        $tokenTime=$tokenTime+20;
                    endif;
                    array_push($thirdTimes,$appointmentTime);
                endfor;
    
                $thirdFinalTimes = [
                    'date'=> Carbon::now()->addDays(2)->format('Y-m-d'),
                    'from'=> $dayAfterTommorowTimeTable->from,
                    'to' => $dayAfterTommorowTimeTable->to,
                    'availableTimes'=>$thirdTimes,
                ];
    
                $doctor->todayAvailableTimes = $todayFinalTimes;
                $doctor->tomorrowAvailableTimes = $tommorowFinalTimes;
                $doctor->dayAfterTomorrowAvailableTimes = $thirdFinalTimes;
                if($doctor->hospital_id)
                    $doctor->hospital = Hospital::where('id',$doctor->hospital_id)->first();
                if($doctor->department_id)
                    $doctor->department = Department::where('id',$doctor->department_id)->first();

            }
            // $tommorowTimeTable = TimeTable::where('doctor_id',$doctor->id)->where('day',$dayOfWeek+1)->first();
            // $dayAfterTommorowTimeTable = TimeTable::where('doctor_id',$doctor->id)->where('day',$dayOfWeek+2)->first();

            
        }
        return response(['status'=>true,'data'=>$doctors]);
    }

    public function doctorDetail($id)
    {
        $doctor = Doctor::findOrFail($id);
        $dayOfWeek = Carbon::now()->dayOfWeek; 
        $todayTimeTable = TimeTable::where('doctor_id',$doctor->id)->where('day',$dayOfWeek)->first();
        $tommorowTimeTable = TimeTable::where('doctor_id',$doctor->id)->where('day',$dayOfWeek+1)->first();
        $dayAfterTommorowTimeTable = TimeTable::where('doctor_id',$doctor->id)->where('day',$dayOfWeek+2)->first();

        $hospital = Hospital::where('id',$doctor->hospital_id)->first();
        if($hospital)
            $fee = $hospital->appointment_fee;
        else
            $fee = $doctor->appointment_fee;

        $doctor->appointment_fee = $fee;

        $todayTimes = [];
        $todayToken = $todayTimeTable->token;
        $tokenTime = 0;
        for($i=0;$i<$todayToken; $i++){
            if($i==0){
                $appointmentTime = $todayTimeTable->from;
            }else{
                $appointmentTime = Carbon::parse($todayTimeTable->from)->addMinutes($tokenTime+20)->format('H:i');
                $tokenTime=$tokenTime+20;
            }
            array_push($todayTimes,$appointmentTime);
        }

        $todayFinalTimes = [
            'date'=>Carbon::now()->format('Y-m-d'),
            'from'=>$todayTimeTable->from,
            'to'=>$todayTimeTable->to,
            'availableTimes'=> $todayTimes,
        ];

        $tommorrowToken = $tommorowTimeTable->token;
        $tokenTime = 0;
        $tommorrowTimes = [];

        for($i=0;$i<$tommorrowToken; $i++):
            if($i==0):
                $appointmentTime = $tommorowTimeTable->from;
            else:
                $appointmentTime = Carbon::parse($tommorowTimeTable->from)->addMinutes($tokenTime+20)->format('H:i');
                $tokenTime=$tokenTime+20;
            endif;
            array_push($tommorrowTimes,$appointmentTime);
        endfor;

        $tommorowFinalTimes = [
            'date'=> Carbon::now()->addDays(1)->format('Y-m-d'),
            'from'=> $tommorowTimeTable->from,
            'to' => $tommorowTimeTable->to,
            'availableTimes'=>$tommorrowTimes,
        ];

        $dayAfterTommorrowToken = $dayAfterTommorowTimeTable->token;
        $tokenTime = 0;
        $thirdTimes = [];
        for($i=0;$i<$dayAfterTommorrowToken; $i++):
            if($i==0):
                $appointmentTime = $dayAfterTommorowTimeTable->from;
            else:
                $appointmentTime = Carbon::parse($tommorowTimeTable->from)->addMinutes($tokenTime+20)->format('H:i'); 
                $tokenTime=$tokenTime+20;
            endif;
            array_push($thirdTimes,$appointmentTime);
        endfor;

        $thirdFinalTimes = [
            'date'=> Carbon::now()->addDays(2)->format('Y-m-d'),
            'from'=> $dayAfterTommorowTimeTable->from,
            'to' => $dayAfterTommorowTimeTable->to,
            'availableTimes'=>$thirdTimes,
        ];

        $doctor->todayAvailableTimes = $todayFinalTimes;
        $doctor->tomorrowAvailableTimes = $tommorowFinalTimes;
        $doctor->dayAfterTomorrowAvailableTimes = $thirdFinalTimes;
        return response(['status'=>true,'data'=>$doctor]);
    }

    public function categories(Request $request)
    {
        $categories = Category::with('subCategory')->get();
        return response(['stats'=>true,'data'=>$categories]);
    }

    public function categoryProducts(Request $request)
    {
        $categoryProducts = Product::where('category_id',$request->category_id)->paginate(20);
        return response(['status'=>true,'data'=>$categoryProducts]);
    }

    public function subCategoryProducts(Request $request)
    {
        $categoryProducts = Product::where('sub_category_id',$request->sub_category_id)->paginate(20);
        return response(['status'=>true,'data'=>$categoryProducts]);
    }

    public function getProducts(Request $request)
    {
        $products = Product::with('category','subCategory');

        if($request->category_id){
            $products = $products->where('category_id',$request->category_id);
        }
        if($request->sub_category_id){
            $products = $products->where('sub_category_id',$request->sub_category_id);
        }
        $products = $products->paginate(20);
        return response(['status'=>true,'products'=>$products]);
    }

    public function mypatients(){
        $patients = Patient::where('user_id',auth()->user()->id)->get();
        return response(['status'=>true,'data'=>$patients]);
    }

    public function myOrders(){
        $orders = Order::with('orderDetail.product')->where('user_id',auth()->user()->id)->get();
        return response(['status'=>true,'data'=>$orders]);
    }

    public function storePrescription(Request $request)
    {
        $prescription = new Prescription();
        if(auth()->user()){
            $user = User::where('id',auth()->user()->id)->first();
            $prescription->name = auth()->user()->name;
            $prescription->mobile = $user->phone_no;
        }else{
            $prescription->name = $request->name;
            $prescription->mobile = $request->mobile;
        }
        $prescription->message = $request->message;
        if ($request->file('path')) {
            $fileName = time() . '_' . $request->file('path')->getClientOriginalName();
            $filePath = $request->file('path')->storeAs('uploads/prescription/file', $fileName, 'public');
            $filePath =  '/storage/uploads/prescription/file/' . $fileName;
        } else {
            $filePath = '';
        }
        $prescription->delivery_address = $request->delivery_address;
        $prescription->path = $filePath;
        $prescription->save();
    }

}

<?php

namespace App\Http\Controllers\API;


use App\User;
use App\Prescription;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PrescriptionController extends Controller
{
    public function store(Request $request)
    {
        $prescription = new Prescription();
        if(auth()->user()){
            $user = User::where('id',auth()->user()->id)->first();
            $prescription->name = auth()->user()->name;
            $prescription->mobile = $user->phone_no;
        }else{
            $prescription->name = $request->name;
            $prescription->mobile = $request->mobile;
        }
        $prescription->message = $request->message;
        if ($request->file('path')) {
            $fileName = time() . '_' . $request->file('path')->getClientOriginalName();
            $filePath = $request->file('path')->storeAs('uploads/prescription/file', $fileName, 'public');
            $filePath =  '/storage/uploads/prescription/file/' . $fileName;
        } else {
            $filePath = '';
        }
        $prescription->delivery_address = $request->delivery_address;
        $prescription->path = $filePath;
        $prescription->save();
        return response([ 'status'=>true,'message'=>'Prescription Uploaded Successfully.','data'=>$prescription]);
    }
}